/*
 * angvel.h
 *
 *  Created on: Jun 11, 2025
 *      Author: danie
 */

#ifndef INC_ANGVEL_H_
#define INC_ANGVEL_H_


#include "stm32f1xx_hal.h"
#include <stdio.h>


extern I2C_HandleTypeDef hi2c1; // Make sure I2C2 is initialized in CubeMX or manually

typedef struct {
	int16_t gx;
	int16_t gy;
	int16_t gz;
	int16_t ax;
	int16_t ay;
	int16_t az;
} MPU6050;

#define MPU6050_ADDR 0x68 << 1 // 7-bit address + write/read bit
#define WHO_AM_I_REG 0x75
#define PWR_MGMT_1   0x6B
#define GYRO_XOUT_H  0x43
#define ACCE_XOUT_H  0x3B
#define ACCEL_WINDOW_SAMPLES 200

typedef struct {
    float ax;
    float ay;
    uint32_t timestamp_ms;
} AccelSample;

typedef struct {
    AccelSample buffer[ACCEL_WINDOW_SAMPLES];
    int size;
    uint32_t window_duration_ms;
} AccelWindow;

void mpu_init();
void mpu_read(MPU6050* mpu);
void mpu_adjust_acc(MPU6050* raw, float* calibrated);
void accel_window_init(AccelWindow* window, uint32_t duration_ms);
void accel_window_add_sample(AccelWindow* window, float ax, float ay, uint32_t now_ms);
float accel_window_get_direction_deg(const AccelWindow* window);


#endif /* INC_ANGVEL_H_ */
