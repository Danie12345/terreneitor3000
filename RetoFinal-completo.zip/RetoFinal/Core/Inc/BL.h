/*
 * BL.h
 *
 *  Created on: Jun 7, 2025
 *      Author: danie
 */

#ifndef __BL_H__
#define __BL_H__

#include "stm32f1xx_hal.h"
#include "stm32f1xx_hal_uart.h"

#define BT_BUF_SIZE 64

extern UART_HandleTypeDef huart3;
extern uint8_t bt_char;
extern uint8_t bt_rx_buffer[BT_BUF_SIZE];
extern uint8_t bt_cursor;
extern volatile uint8_t bt_cmd_ready;
extern char bt_last_cmd[BT_BUF_SIZE];

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t size);
char BL_ParseCommand();

#endif // __BL_H__
