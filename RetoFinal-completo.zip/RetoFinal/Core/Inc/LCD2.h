/*
 * LCD2.h
 *
 *  Created on: May 23, 2025
 *      Author: danie
 */



#ifndef INC_LCD2_H_
#define INC_LCD2_H_

#include "stm32f1xx.h"


extern I2C_HandleTypeDef hi2c1;
extern uint8_t data;

#define LCD_ADDR (0x27 << 1)
#define LCD_BACKLIGHT 0x08

void lcd_send_cmd(uint8_t cmd);
void lcd_send_data(uint8_t data);
void lcd_send_string(char *str);
void lcd_init(void);
void lcd_clear(void);
void lcd_display_vec(float* arr);
void lcd_set_cursor(uint8_t row, uint8_t col);



#endif /* INC_LCD2_H_ */
