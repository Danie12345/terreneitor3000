/*
 * mag.h
 *
 *  Created on: Jun 7, 2025
 *      Author: danie
 */

#ifndef INC_MAG_H_
#define INC_MAG_H_

#include "stm32f1xx_hal.h"

#define HMC5883L_ADDR (0x1E << 1)

// Control register bits
#define QMC5883_MODE_CONTINUOUS 0b00000001
#define QMC5883_ODR_50HZ        0b00001100
#define QMC5883_RNG_2G          0b00010000
#define QMC5883_OSR_512         0b11000000
// QMC5883 7-bit address is 0x0D → write = 0x1A, read = 0x1B
#define QMC5883_ADDR      (0x0D << 1)
#define QMC5883_REG_CTRL1 0x09
#define QMC5883_REG_DATA  0x00

extern I2C_HandleTypeDef hi2c1;

typedef struct {
    int16_t x;
    int16_t y;
    int16_t z;
} MagData;

void mag_init(void);
void mag_read(MagData* mag);
void mag_get_scaled(MagData* raw, float* scaled);

#endif /* INC_HW127_H_ */
