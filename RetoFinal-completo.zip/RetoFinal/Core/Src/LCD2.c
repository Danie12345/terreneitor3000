/*
 * LCD2.c
 *
 *  Created on: May 23, 2025
 *      Author: danie
 */

#include <LCD2.h>

#include <stdio.h>
#include <string.h>
#include "stm32f1xx.h"

extern I2C_HandleTypeDef hi2c1;
uint8_t data;

void lcd_send_cmd(uint8_t cmd) {
    uint8_t upper = cmd & 0xF0;
    uint8_t lower = (cmd << 4) & 0xF0;
    uint8_t data_t[4];
    data_t[0] = upper | LCD_BACKLIGHT | 0x04;
    data_t[1] = upper | LCD_BACKLIGHT;
    data_t[2] = lower | LCD_BACKLIGHT | 0x04;
    data_t[3] = lower | LCD_BACKLIGHT;
    HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, data_t, 4, 100);
}

void lcd_send_data(uint8_t data) {
    uint8_t upper = data & 0xF0;
    uint8_t lower = (data << 4) & 0xF0;
    uint8_t data_t[4];
    data_t[0] = upper | LCD_BACKLIGHT | 0x05;
    data_t[1] = upper | LCD_BACKLIGHT | 0x01;
    data_t[2] = lower | LCD_BACKLIGHT | 0x05;
    data_t[3] = lower | LCD_BACKLIGHT | 0x01;
    HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, data_t, 4, 100);
}

void lcd_send_string(char *str) {
    while (*str) {
        lcd_send_data(*str++);
    }
}

void lcd_set_cursor(uint8_t row, uint8_t col) {
    uint8_t pos[] = {0x80, 0xC0};
    lcd_send_cmd(pos[row] + col);
}

void lcd_clear(void) {
	lcd_set_cursor(0, 0);
	lcd_send_string("                ");
	lcd_set_cursor(1, 0);
	lcd_send_string("                ");
	lcd_set_cursor(0, 0);
}

void lcd_display_vec(float* arr) {
    char line1[17], line2[17];
    snprintf(line1, sizeof(line1), "%.2f,%.2f", arr[0], arr[1]);
    snprintf(line2, sizeof(line2), "%.2f", arr[2]);
    lcd_clear();
    lcd_set_cursor(0, 0);
    lcd_send_string(line1);
    lcd_set_cursor(1, 0);
    lcd_send_string(line2);
}


void lcd_init(void) {
    HAL_Delay(50);
    lcd_send_cmd(0x33);
    HAL_Delay(5);
    lcd_send_cmd(0x32);
    HAL_Delay(5);
    lcd_send_cmd(0x28);
    lcd_send_cmd(0x0C);
    lcd_send_cmd(0x06);
    lcd_send_cmd(0x01);
    HAL_Delay(5);
}

