/*
 * BL.c
 *
 *  Created on: Jun 7, 2025
 *      Author: danie
 */

#include "BL.h"
#include "LCD2.h"
#include <string.h>
#include <stdio.h>

#define BT_BUF_SIZE 64

uint8_t bt_char = 0;
uint8_t bt_rx_buffer[BT_BUF_SIZE];
uint8_t bt_cursor = 0;
volatile uint8_t bt_cmd_ready = 0;
char bt_last_cmd[BT_BUF_SIZE];

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size) {
	if (huart->Instance == USART3) {
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		strncpy(bt_last_cmd, (const char *)bt_rx_buffer, sizeof(bt_rx_buffer));
		lcd_clear();
		lcd_send_string(bt_last_cmd);
		memset(bt_rx_buffer, 0, sizeof(bt_rx_buffer));
		HAL_UARTEx_ReceiveToIdle_IT(huart, bt_rx_buffer, sizeof(bt_rx_buffer));
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
	}
}

char BL_ParseCommand() {
//    static char parsed[BT_BUF_SIZE];
//    int j = 0;
//    for (int i = 0; input[i] != '\0' && j < BT_BUF_SIZE - 1; ++i) {
//        if (input[i] >= '0' && input[i] <= '9') {
//            parsed[j++] = input[i];
//        }
//    }
//    parsed[j] = '\0';
    return bt_last_cmd[0];
}
