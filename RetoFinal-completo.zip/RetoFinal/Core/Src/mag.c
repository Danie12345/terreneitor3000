/*
 * mag.c
 *
 *  Created on: Jun 7, 2025
 *      Author: danie
 */

#include "mag.h"
#include "stm32f1xx_hal.h"

#define HMC5883L_ADDR (0x1E << 1)

// Control register bits
#define QMC5883_MODE_CONTINUOUS 0b00000001
#define QMC5883_ODR_50HZ        0b00001100
#define QMC5883_RNG_2G          0b00010000
#define QMC5883_OSR_512         0b11000000

// QMC5883 7-bit address is 0x0D → write = 0x1A, read = 0x1B
#define QMC5883_ADDR      (0x0D << 1)
#define QMC5883_REG_CTRL1 0x09
#define QMC5883_REG_DATA  0x00

extern I2C_HandleTypeDef hi2c1;

void mag_init(void) {
	uint8_t config = QMC5883_OSR_512 | QMC5883_RNG_2G | QMC5883_ODR_50HZ | QMC5883_MODE_CONTINUOUS;
	HAL_I2C_Mem_Write(&hi2c1, HMC5883L_ADDR, QMC5883_REG_CTRL1, 1, &config, 1, HAL_MAX_DELAY);
//    HAL_Delay(70);
//    uint8_t config[3];
//    config[0] = 0x00; config[1] = 0x70;
//    HAL_I2C_Mem_Write(&hi2c1, HMC5883L_ADDR, config[0], 1, &config[1], 1, HAL_MAX_DELAY);
//    HAL_Delay(10);
//    config[0] = 0x01; config[1] = 0xE0;
//    HAL_I2C_Mem_Write(&hi2c1, HMC5883L_ADDR, config[0], 1, &config[1], 1, HAL_MAX_DELAY);
//    // change to continuous mode
//    uint8_t config_reg_a[2] = {0x00, 0x70};  // CRA
//    uint8_t config_reg_b[2] = {0x01, 0x00};  // CRB
//    uint8_t mode_reg[2]     = {0x02, 0x00};  // Mode = Continuous
//    HAL_I2C_Mem_Write(&hi2c1, HMC5883L_ADDR, config_reg_a[0], 1, &config_reg_a[1], 1, HAL_MAX_DELAY);
//    HAL_Delay(10);
//    HAL_I2C_Mem_Write(&hi2c1, HMC5883L_ADDR, config_reg_b[0], 1, &config_reg_b[1], 1, HAL_MAX_DELAY);
//    HAL_Delay(10);
//    HAL_I2C_Mem_Write(&hi2c1, HMC5883L_ADDR, mode_reg[0], 1, &mode_reg[1], 1, HAL_MAX_DELAY);
//    HAL_Delay(70);
}

void mag_read(MagData* mag) {
//    uint8_t buffer[6];
//    HAL_I2C_Mem_Read(&hi2c1, HMC5883L_ADDR, 0x00, 1, buffer, 6, HAL_MAX_DELAY);
    uint8_t buffer[6];
	HAL_I2C_Mem_Read(&hi2c1, QMC5883_ADDR, QMC5883_REG_DATA, 1, buffer, 6, HAL_MAX_DELAY);
    // junta los bytes de los registros 03 y 04, 05 y 06, 07 y 08 en dos bytes
    mag->x = (int16_t)(buffer[1] << 8 | buffer[0]);
    mag->z = (int16_t)(buffer[3] << 8 | buffer[2]);
    mag->y = (int16_t)(buffer[5] << 8 | buffer[4]);
}

void mag_get_scaled(MagData* raw, float* scaled) {
    const float scale = 1.0f;//1.0f / 1090.0f;
    scaled[0] = raw->x * scale;
    scaled[1] = raw->y * scale;
    scaled[2] = raw->z * scale;
}

