/*
 * angvel.c
 *
 *  Created on: Jun 11, 2025
 *      Author: danie
 */


#include <stdio.h>
#include "stm32f1xx_hal.h"
#include "angvel.h"
#include <math.h>

extern I2C_HandleTypeDef hi2c1; // Make sure I2C2 is initialized in CubeMX or manually

#define MPU6050_ADDR 0x68 << 1 // 7-bit address + write/read bit
#define WHO_AM_I_REG 0x75
#define PWR_MGMT_1   0x6B
#define GYRO_XOUT_H  0x43
#define ACCE_XOUT_H  0x3B
#define ACCEL_WINDOW_SAMPLES 200

void mpu_init() {
    uint8_t check;
    uint8_t data;
    HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR, WHO_AM_I_REG, 1, &check, 1, HAL_MAX_DELAY);
    if (check == 0x68) {
        data = 0;
        HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, PWR_MGMT_1, 1, &data, 1, HAL_MAX_DELAY);
    }
}

void mpu_read(MPU6050* mpu) {
    uint8_t bufferG[6];
    uint8_t bufferA[6];

    // Read 6 bytes starting from GYRO_XOUT_H
    HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR, GYRO_XOUT_H, 1, bufferG, sizeof(bufferG), HAL_MAX_DELAY);
    HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR, ACCE_XOUT_H, 1, bufferA, sizeof(bufferA), HAL_MAX_DELAY);

    mpu->gx = (int16_t)(bufferG[0] << 8 | bufferG[1]);
    mpu->gy = (int16_t)(bufferG[2] << 8 | bufferG[3]);
    mpu->gz = (int16_t)(bufferG[4] << 8 | bufferG[5]);
    mpu->ax = (int16_t)(bufferA[0] << 8 | bufferA[1]);
    mpu->ay = (int16_t)(bufferA[2] << 8 | bufferA[3]);
    mpu->az = (int16_t)(bufferA[4] << 8 | bufferA[5]);
}

void mpu_adjust_acc(MPU6050* raw, float* calibrated) {
    const float scale = 1.0f / 16384.0f;
    calibrated[0] = raw->ax * scale - 0.0377784;
    calibrated[1] = raw->ay * scale - 0.0025238;
    calibrated[2] = raw->az * scale - 0.0519445;
}

void accel_window_init(AccelWindow* window, uint32_t duration_ms) {
    window->size = 0;
    window->window_duration_ms = duration_ms;
}

void accel_window_add_sample(AccelWindow* window, float ax, float ay, uint32_t now_ms) {
    if (window->size < ACCEL_WINDOW_SAMPLES) {
        window->buffer[window->size++] = (AccelSample){ ax, ay, now_ms };
    } else {
        for (int i = 1; i < ACCEL_WINDOW_SAMPLES; i++) {
            window->buffer[i - 1] = window->buffer[i];
        }
        window->buffer[ACCEL_WINDOW_SAMPLES - 1] = (AccelSample){ ax, ay, now_ms };
    }
    int i = 0;
    while (i < window->size && (now_ms - window->buffer[i].timestamp_ms > window->window_duration_ms)) {
        i++;
    }
    if (i > 0) {
        for (int j = i; j < window->size; j++) {
            window->buffer[j - i] = window->buffer[j];
        }
        window->size -= i;
    }
}

float accel_window_get_direction_deg(const AccelWindow* window) {
    if (window->size == 0) return 90.0f;
    const float threshold = 0.55f;
    float sum_ax = 0.0f;
    float sum_ay = 0.0f;
    for (int i = 0; i < window->size; i++) {
        sum_ax += window->buffer[i].ax;
        sum_ay += window->buffer[i].ay;
    }
    float avg_ax = sum_ax / window->size;
    float avg_ay = sum_ay / window->size;
    float avg_magnitude = sqrtf(avg_ax * avg_ax + avg_ay * avg_ay);
    if (avg_magnitude < threshold) {
        return 90.0f;
    }
    float yaw_rad = atan2f(avg_ay, avg_ax);
    float yaw_deg = yaw_rad * (180.0f / M_PI);
    yaw_deg += 90.0f;
    if (yaw_deg < 0.0f) yaw_deg += 360.0f;
    if (yaw_deg >= 360.0f) yaw_deg -= 360.0f;
    return yaw_deg;
}



